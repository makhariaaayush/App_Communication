package com.example.a1;
;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;


public class Receiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String url = intent.getStringExtra("URL");
        Intent i = new Intent(context, Web.class);
        i.putExtra("URL", url);
//intent to pass the URL Received from App3
        context.startActivity(i);
    }
}


