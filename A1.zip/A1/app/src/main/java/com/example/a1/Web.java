package com.example.a1;

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web);
//Receiving URL from Receiver Class
        String URL = getIntent().getStringExtra("URL");
        Toast.makeText(this, "URL Opening", Toast.LENGTH_SHORT).show();
        if (URL == null) {
            finish();
            Toast.makeText(this, "URL is NUll", Toast.LENGTH_SHORT).show();
            return;

        }
//URL being deployed suing Webview
        WebView webView = findViewById(R.id.web);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(URL);
        Toast.makeText(this, "URL Opened", Toast.LENGTH_SHORT).show();

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
