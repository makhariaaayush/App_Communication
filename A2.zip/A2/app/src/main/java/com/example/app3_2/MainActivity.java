package com.example.app3_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //    Variable for Opeing Web
    private final static String WEB = "edu.uic.cs478.s19.WEB";
    //    Variable for Starting App 3
    private final static String StartA3 = "edu.uic.cs478.s19.A3";
    //    Variable for Destroying
    private final static String My_Permission = "edu.uic.cs478.s19.kaboom";


    private final static int req_code = 0;
    private Receiver r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(v -> permission_check());
    }
    //Permission Check
    public void permission_check(){
        if (checkSelfPermission(My_Permission) == PackageManager.PERMISSION_GRANTED){
            if (r == null){
                r = new Receiver();
                registerReceiver(r, new IntentFilter(WEB));
                Toast.makeText(this, "The Receiver has Started!", Toast.LENGTH_SHORT).show();
            }
//            Intent creation for starting Activity 2

            Intent intent = new Intent();
            intent.setAction(StartA3);
            startActivity(intent);
        }

        else {
            requestPermissions(new String[]{My_Permission}, req_code);
        }
    }
//      Granting Permission Check
    @Override
    public void onRequestPermissionsResult(int reqCode, @NonNull String[] permissions, @NonNull int[] results) {
        if (reqCode == req_code) {
            if (results.length > 0 &&
                    results[0] == PackageManager.PERMISSION_GRANTED) {

                permission_check();
            }

            else {
                finish();
            }
        }
    }
    //    Destroying Activity

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (r != null){
            unregisterReceiver(r);
        }
    }
}
