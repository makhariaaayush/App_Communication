package com.example.project3_app3;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class Show_Fragment extends Fragment {

    private ImageView imageview = null;
    private int curr = -1;
    private int arr = 0;

    int getShownIndex() {

        return curr;
    }
//Used for setting the Image fragment
    void showShowAtIndex(int newIndex) {
        if (newIndex < 0 || newIndex >= arr)
            return;
        curr = newIndex;
        imageview.setImageResource(MainActivity.images[curr]);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.show, container, false);
    }
//used for showing image fragment
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        imageview = requireActivity().findViewById(R.id.imgView);
        arr = MainActivity.images.length;
        showShowAtIndex(curr);
    }

    @Override
    public void onAttach(@NonNull Context activity) {
        super.onAttach(activity);
    }
    @Override
    public void onStart() {
        super.onStart();
    }
    @Override
    public void onResume() {
        super.onResume();
    }
    @Override
    public void onPause() {
        super.onPause();
    }
    @Override
    public void onStop() {
        super.onStop();
    }
    @Override
    public void onDetach() {
        super.onDetach();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}

