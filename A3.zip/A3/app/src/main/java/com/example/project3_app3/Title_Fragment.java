package com.example.project3_app3;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import static android.widget.AbsListView.CHOICE_MODE_SINGLE;

public class Title_Fragment extends ListFragment {
    private ListSelectionListener listener = null;
    private int curr = -1;

    public interface ListSelectionListener {
        void onListSelection(int index);
    }

    @Override
    public void onListItemClick(@NonNull ListView l, @NonNull View v, int p, long id) {
        curr = p;
        l.setItemChecked(curr,true);
        listener.onListSelection(p);
    }

    @Override
    public void onAttach(@NonNull Context activity) {
        super.onAttach(activity);

        try {

            listener = (ListSelectionListener) activity;

        } catch (ClassCastException e) {

            throw new ClassCastException(activity.toString());
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

//used for seeting the title of TV show
    @Override
    public void onActivityCreated(Bundle savedState) {
        super.onActivityCreated(savedState);

        getListView().setChoiceMode(CHOICE_MODE_SINGLE);

        setListAdapter(new ArrayAdapter<>(getActivity(),
                R.layout.title, MainActivity.mTitleArray));    }

    @Override
    public void onStop() {
        super.onStop();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    @Override
    public void onDetach() {
        super.onDetach();
    }
    @Override
    public void onPause() {
        super.onPause();
    }
    @Override
    public void onResume() {
        super.onResume();
    }
    @Override
    public void onStart() {
        super.onStart();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}
