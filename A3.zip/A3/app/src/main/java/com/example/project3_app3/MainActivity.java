package com.example.project3_app3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements Title_Fragment.ListSelectionListener {

    public static String[] mTitleArray;
    private String showFragment = "Show";
    private String titleFragment = "Title";
    private Show_Fragment ShowFragment;
    private Title_Fragment TitleFragment;
    public static String[] showURL;

    public static int[] images = {R.drawable.breakingbad, R.drawable.flash, R.drawable.houseofcards,
            R.drawable.modernfamily, R.drawable.moneyheist, R.drawable.sacred_games, R.drawable.umbrellaacademy};

    private final static String WEB = "edu.uic.cs478.s19.WEB";

    private final static String My_Permission = "edu.uic.cs478.s19.kaboom";


    private boolean selectItem = false;

    FragmentManager FragmentManager;

    private FrameLayout tFrame, sFrame;
    private static final int MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        getSupportActionBar().setLogo(R.drawable.ic_launcher_background);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        mTitleArray = getResources().getStringArray(R.array.TV);
        showURL = getResources().getStringArray(R.array.URL);


        setContentView(R.layout.activity_main);

        tFrame = findViewById(R.id.title_container);
        sFrame = findViewById(R.id.show_container);

        FragmentManager = getSupportFragmentManager();
        FragmentManager.addOnBackStackChangedListener(
                new FragmentManager.OnBackStackChangedListener() {
                    public void onBackStackChanged() {
                        setLayout();
                    }
                });

        ShowFragment = (Show_Fragment) FragmentManager.findFragmentByTag(showFragment);
        TitleFragment = (Title_Fragment) FragmentManager.findFragmentByTag(titleFragment);
        if(TitleFragment == null) {
            TitleFragment = new Title_Fragment();
        }

        FragmentTransaction fragmentTransaction = FragmentManager.beginTransaction();

        if(ShowFragment == null) {
            ShowFragment = new Show_Fragment();
        } else {
            if(!ShowFragment.isAdded()) {
                fragmentTransaction = FragmentManager.beginTransaction();
                fragmentTransaction.add(R.id.show_container, ShowFragment, showFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                FragmentManager.executePendingTransactions();
            }
            setLayout();
        }

        fragmentTransaction.replace( R.id.title_container, TitleFragment, titleFragment );

        fragmentTransaction.commit();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);

        return true;
    }

    /*Performs tasks according to option selected*/
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            /*Opens A1 and A2*/
            case R.id.menu1:
                if (!selectItem){
                }

                else{
                    Intent intent = new Intent();
                    intent.setAction(WEB);
                    int index = ShowFragment.getShownIndex();
                    intent.putExtra("URL", showURL[index]);
                    sendOrderedBroadcast(intent, My_Permission);
                }
                return true;

            /*Exits from Application*/
            case R.id.menu2:
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

//on orientation change  changing the weight
    private void setLayout() {
        int orientation = this.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE){
            tFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT, 1f));

            sFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT, 2f));
        }
        else if (!ShowFragment.isAdded()) {

            tFrame.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT));
            sFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT));
        }

        else{

            // Make the TitleLayout take none of the layout's width
            tFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT, 0f));

            sFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH_PARENT, 3f));
        }
    }

    @Override
    public void onListSelection(int index) {

        if (!ShowFragment.isAdded()) {

            FragmentTransaction fragmentTransaction = FragmentManager.beginTransaction();

            fragmentTransaction.add(R.id.show_container, ShowFragment, showFragment);

            fragmentTransaction.addToBackStack(null);

            fragmentTransaction.commit();

            FragmentManager.executePendingTransactions();
        }

        selectItem = true;

        if (ShowFragment.getShownIndex() != index) {

            ShowFragment.showShowAtIndex(index);

        }
        setLayout();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    @Override
    protected void onPause() {
        super.onPause();
    }
    @Override
    protected void onRestart() {
        super.onRestart();
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onStart() {
        super.onStart();
    }
    @Override
    protected void onStop() {
        super.onStop();
    }
}